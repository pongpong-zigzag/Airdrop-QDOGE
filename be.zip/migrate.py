from app.core.db import init_db

if __name__ == "__main__":
    init_db()
    print("Migrations applied OK.")
