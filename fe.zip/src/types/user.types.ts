export type OwnedAssetSnapshot = {
  asset: string;
  amount: number;
  issuerId: string;
  unitOfMeasurement: number[];
};

