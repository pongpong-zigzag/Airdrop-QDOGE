"use client";

import React, { useState } from 'react';
import { useQubicConnect } from '@/components/connect/QubicConnectContext';
import { useWalletConnect } from '@/components/connect/WalletConnectContext';
import { fetchBalance } from '@/services/rpc.service';
import { saveTransaction } from '@/lib/api';
import { toast } from 'react-hot-toast';

interface BuyGamesTransactionProps {
  onPurchaseComplete: () => void;
}

const ACCESS_PRICE = 100; // 100 QU for airdrop access
const QU_MIN_BALANCE = 10000
const RECIPIENT_ADDRESS = 'KZFJRTYKJXVNPAYXQXUKMPKAHWWBWVWGLSFMEFOKPFJFWEDDXMCZVSPEOOZE'; // QU recipient address

const TxPay: React.FC<BuyGamesTransactionProps> = ({ onPurchaseComplete }) => {
  const { connected, wallet } = useQubicConnect();
  const { sendQubic } = useWalletConnect();
  const [, setIsProcessing] = useState(false);

  // This component listens for buy games requests and leaderboard payment requests
  React.useEffect(() => {
    const handlePayFundRequest = async (event: Event) => {
      const customEvent = event as CustomEvent<{ payload: {amount:number} }>;
      const payload = customEvent.detail || { amount: 0 };
                                                                                                                                                                                                                   
      if (!connected || !wallet || payload.amount === 0) {
        toast.error('Please connect your wallet first');
        return;
      }

      await handlePayFund(payload.amount);
    };

    const handlePayAccessRequest = async () => {
      if (!connected || !wallet) {
        toast.error('Please connect your wallet first');
        return;
      }

    //   await handlePayAccess();
    };

    window.addEventListener('payFund', handlePayFundRequest as EventListener);
    window.addEventListener('payAccess', handlePayAccessRequest as EventListener);
    return () => {
      window.removeEventListener('payFund', handlePayFundRequest as EventListener);
      window.removeEventListener('payAccess', handlePayAccessRequest as EventListener);
    };
  }, [connected, wallet]);

//   const handlePayAccess = async () => {
//     if (!connected || !wallet) {
//       toast.error('Please connect your wallet first');
//       return;
//     }

//     if (wallet.connectType !== 'walletconnect') {
//       toast.error('QXMR payments currently require WalletConnect');
//       return;
//     }

//     setIsProcessing(true);
//     const totalAmount = ACCESS_PRICE;

//     try {
//       // Check balance before sending transaction
//       toast.loading('Checking balance...', { id: 'balance-check' });
//       const balanceData = await fetchBalance(wallet.publicKey);
//       const balance = balanceData.balance;
//       const availableBalance = balance || 0;
      
//       toast.dismiss('balance-check');
      
//       if (availableBalance < totalAmount) {
//         toast.error(`Insufficient balance. You have ${availableBalance} QXMR, but need ${totalAmount} QXMR for leaderboard access.`);
//         setIsProcessing(false);
//         return;
//       }
      
//       toast.success(`Balance: ${availableBalance} QXMR`, { duration: 2000 });

//       const sourceAddress = wallet.publicKey?.toUpperCase().trim();
//       const destAddress = RECIPIENT_ADDRESS.toUpperCase().trim();

//       toast.loading('Confirm QXMR transfer in your wallet...', { id: 'signing' });
//       const sendQubicResult = await sendQubic({
//         from: sourceAddress,
//         to: destAddress,
//         amount: totalAmount,
//       });

//       toast.dismiss('signing');

//       if (sendQubicResult && sendQubicResult.hash) {
//         const txId = sendQubicResult.hash;

//         // Save transaction to backend with leaderboard_payment type
//         try {
//           const result = await saveTransaction({
//             walletid: wallet.publicKey,
//             hash: txId,
//             paid: totalAmount,
//             col1: 'leaderboard_payment',
//             col2: '1',
//           });
          
//           toast.dismiss('pay-leaderboard');
//           if (result.leaderboard_access_granted) {
//             toast.success('Leaderboard access granted! Your scores will now appear on the leaderboard.');
//           } else {
//             toast.success('Transaction successful! Leaderboard access will be granted shortly.');
//           }
//           onPurchaseComplete();
//         } catch (error) {
//           console.error('Error saving transaction:', error);
//           toast.dismiss('pay-leaderboard');
//           toast.error('Transaction sent but failed to grant access. Please contact support.');
//         }
//       } else {
//         toast.error('Transaction failed');
//       }
//     } catch (error: any) {
//       console.error('Error processing leaderboard payment:', error);
//       toast.error(`Transaction failed: ${error?.message || 'Unknown error'}`);
//     } finally {
//       setIsProcessing(false);
//     }
//   };

  const handlePayFund = async (amount: number) => {
    if (!connected || !wallet) {
      toast.error('Please connect your wallet first');
      return;
    }

    console.log(wallet.connectType);

    setIsProcessing(true);
    const totalAmount = amount;
    console.log(totalAmount);

    try {
      toast.loading('Checking balance...', { id: 'balance-check' });
      const balanceData = await fetchBalance(wallet.publicKey);
      const availableBalance = balanceData.balance;
      console.log(balanceData);

      toast.dismiss('balance-check');

      if (availableBalance < totalAmount) {
        toast.error(`Insufficient balance. You have ${availableBalance} QU, but need ${totalAmount} QU.`);
        setIsProcessing(false);
        return;
      }

      if( (availableBalance - totalAmount) < QU_MIN_BALANCE) {
        toast.error(`You need to keep at least ${QU_MIN_BALANCE} QU in your wallet.`);
        setIsProcessing(false);
        return;
      }

      toast.success(`Balance: ${availableBalance} QU`, { duration: 2000 });

      const sourceAddress = wallet.publicKey?.toUpperCase().trim();
      const destAddress = RECIPIENT_ADDRESS.toUpperCase().trim();

      toast.loading('Confirm QU transfer in your wallet...', { id: 'signing' });
      const sendQubicResult = await sendQubic({
        from: sourceAddress,
        to: destAddress,
        amount: totalAmount,
      });

      toast.dismiss('signing');

      console.log(sendQubicResult);

    //   if (sendAssetResult && sendAssetResult.transactionId) {
    //     const txId = sendAssetResult.transactionId;

    //     // Save transaction to backend (this will automatically add games)
    //     try {
    //       const result = await saveTransaction({
    //         walletid: wallet.publicKey,
    //         hash: txId,
    //         paid: totalAmount,
    //         col1: 'game_purchase',
    //         col2: games.toString(),
    //       });
          
    //       toast.dismiss('buy-games');
    //       if (result.games_added && result.games_added > 0) {
    //         toast.success(`Transaction successful! ${result.games_added} game(s) added to your account.`);
    //       } else {
    //         toast.success('Transaction successful! Games will be added shortly.');
    //       }
    //       onPurchaseComplete();
    //     } catch (error) {
    //       console.error('Error saving transaction:', error);
    //       toast.dismiss('buy-games');
    //       toast.error('Transaction sent but failed to update games. Please contact support.');
    //     }
    //   } else {
    //     toast.error('Transaction failed');
    //   }
    } catch (error: any) {
      console.error('Error processing purchase:', error);
      toast.error(`Transaction failed: ${error?.message || 'Unknown error'}`);
    } finally {
      setIsProcessing(false);
    }
  };

  // This component doesn't render anything, it just handles transactions
  return null;
};

export default TxPay;

