export const tickOffset = 10;
export const connectTypes = ["privateKey", "vaultFile", "mmSnap", "walletconnect"];
