/**
 * The snap origin to use.
 * Will default to the local hosted snap.
 */
export const defaultSnapOrigin = `npm:@qubic-lib/qubic-mm-snap`;
