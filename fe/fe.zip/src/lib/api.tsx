const BASE = process.env.NEXT_PUBLIC_API_BASE_URL!;

import {User, Res} from "./types"


export async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers || {}),
    },
  });

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`API ${res.status}: ${text || res.statusText}`);
  }
  return res.json() as Promise<T>;
}

export const getUser = async (walletId: string): Promise<{ user: User; created: boolean }> => {
  const res = await fetch(`${BASE}/get_user`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ walletId }),
  });

  if(!res.ok) {
    const error = await res.json();
    throw new Error( error.error || 'Failed to get user');
  }

  return res.json();
}

export const getAirdropRes = async (): Promise<{ res: Res[] }> => {
  const res = await fetch(`${BASE}/get_airdrop_res`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
  });

  if(!res.ok){
    const error = await res.json();
    throw new Error( error.error || 'Failed to get Result Table');
  }

  return res.json();
}

export const fundForAirdrop = async (payload: {amount: number}, mode: string): Promise<{ Res: Res }> => {
  const totalAmount = payload.amount;

  return { Res: { no: 0, wallet_id: "", qearn_bal: 0, invest_bal: 0, airdrop_amt: 0, created_at: "", updated_at: "" } };
}

export const saveTransaction = async (data: TransactionRequest): Promise<{
  success: boolean;
  transaction_saved: boolean;
  user_paid_updated: string;
  games_added?: number;
  games_remaining?: number;
  leaderboard_access_granted?: boolean;
}> => {
  const response = await fetch(`${BASE}/transaction`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Failed to save transaction');
  }

  return response.json();
};